import joblib
import pandas as pd
import logging
import os

logger = logging.getLogger(__name__)

class IFRS9ModelService:
    def __init__(self, model_path: str = "models/ifrs9_stage2_model.pkl"):
        self.model_path = model_path
        self.model = None
        self.scaler = None
        self.imputer = None
        self.feature_columns = None
        self.optimal_threshold = 0.5
        self.load_artifacts()

    def load_artifacts(self):
        """Loads the model and preprocessing artifacts into memory."""
        if not os.path.exists(self.model_path):
            raise FileNotFoundError(f"Model artifact not found at {self.model_path}")
            
        logger.info(f"Loading IFRS9 model artifacts from {self.model_path}...")
        artifacts = joblib.load(self.model_path)
        
        self.model = artifacts['model']
        self.scaler = artifacts['scaler']
        self.imputer = artifacts['imputer']
        self.feature_columns = artifacts['feature_columns']
        self.optimal_threshold = artifacts.get('optimal_threshold', 0.5)
        logger.info("Artifacts loaded successfully.")

    def predict(self, input_data: list[dict]) -> list[dict]:
        """Runs the preprocessing and prediction pipeline."""
        df = pd.DataFrame(input_data)
        
        # Ensure new data has all required training features
        missing_features = set(self.feature_columns) - set(df.columns)
        if missing_features:
            logger.warning(f"Missing features filled with 0: {missing_features}")
            for feat in missing_features:
                df[feat] = 0.0
                
        # Order columns exactly as trained
        X_new = df[self.feature_columns].copy()
        
        # Preprocessing
        X_new_imputed = self.imputer.transform(X_new)
        X_new_scaled = self.scaler.transform(X_new_imputed)
        
        # Inference
        probabilities = self.model.predict_proba(X_new_scaled)[:, 1]
        predictions = (probabilities >= self.optimal_threshold).astype(int)
        
        # Risk tiering
        risk_tiers = pd.cut(probabilities, 
                            bins=[0, 0.2, 0.4, 0.6, 0.8, 1.0], 
                            labels=['Very Low', 'Low', 'Medium', 'High', 'Very High'],
                            include_lowest=True)
        
        results = []
        for i in range(len(df)):
            p = probabilities[i]
            results.append({
                "loan_id": str(df.iloc[i].get('loan_id', f"batch_{i}")),
                "migration_probability": round(float(p), 4),
                "predicted_migration": int(predictions[i]),
                "risk_tier": str(risk_tiers[i]),
                "recommended_action": 'Monitor' if p < 0.3 else 'Review' if p < 0.6 else 'Immediate Review'
            })
            
        return results