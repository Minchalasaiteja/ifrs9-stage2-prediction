from prometheus_client import Counter, Histogram
import json
import logging
import os
from datetime import datetime

# Prometheus Metrics
PREDICTION_COUNTER = Counter(
    'ifrs9_predictions_total',
    'Total number of predictions made',
    ['risk_tier', 'predicted_migration']
)

LATENCY_HISTOGRAM = Histogram(
    'ifrs9_prediction_latency_seconds',
    'Latency of prediction requests'
)

# Drift Logger Setup
os.makedirs("logs", exist_ok=True)
drift_logger = logging.getLogger("drift_logger")
drift_logger.setLevel(logging.INFO)
file_handler = logging.FileHandler("logs/prediction_audit_log.jsonl")
formatter = logging.Formatter('%(message)s')
file_handler.setFormatter(formatter)
drift_logger.addHandler(file_handler)

def log_prediction_for_audit(input_data: dict, prediction_result: dict):
    """
    Logs the raw input and the model's output as JSONL.
    This file can be ingested by tools like Evidently AI or ELK 
    to monitor for Data Drift and Concept Drift.
    """
    audit_record = {
        "timestamp": datetime.utcnow().isoformat(),
        "input_features": input_data,
        "prediction": prediction_result
    }
    drift_logger.info(json.dumps(audit_record))

def record_metrics(risk_tier: str, predicted_migration: int):
    """Updates Prometheus metrics."""
    PREDICTION_COUNTER.labels(
        risk_tier=risk_tier, 
        predicted_migration=str(predicted_migration)
    ).inc()