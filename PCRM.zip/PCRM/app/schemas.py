from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional

class LoanInput(BaseModel):
    """
    Strict data schema for the incoming loan prediction requests.
    We define the most common raw features. Extra fields are allowed 
    to handle engineered features that might be passed directly.
    """
    model_config = ConfigDict(extra='allow')

    loan_id: str = Field(..., description="Unique identifier for the loan")
    loan_amount_gbp: float = Field(..., description="Original loan amount")
    outstanding_balance_gbp: float = Field(..., description="Current outstanding balance")
    original_loan_term_months: float = Field(..., description="Original term in months")
    remaining_term_months: float = Field(..., description="Remaining term in months")
    interest_rate_pct: float = Field(..., description="Current interest rate")
    vintage_year: float = Field(..., description="Year of origination")
    
    internal_credit_score: float = Field(..., description="Internal behavioral score")
    credit_score_change_last_quarter: float = Field(0.0, description="Change in score")
    bureau_inquiries_last_6m: float = Field(0.0, description="Recent credit inquiries")
    
    days_past_due_current: float = Field(0.0, description="Current days past due")
    missed_payments_last_12m: float = Field(0.0, description="Missed payments in last 12m")
    months_on_book: float = Field(..., description="Age of the loan in months")
    
    pd_12m_at_origination_pct: float = Field(..., description="Original 12m PD")
    pd_12m_current_pct: float = Field(..., description="Current 12m PD")
    pd_relative_change_pct: float = Field(..., description="Relative change in PD")

class PredictionOutput(BaseModel):
    loan_id: str
    migration_probability: float
    predicted_migration: int
    risk_tier: str
    recommended_action: str

class BatchPredictionOutput(BaseModel):
    predictions: List[PredictionOutput]